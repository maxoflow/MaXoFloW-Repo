#!/bin/bash
openbox &
/usr/bin/google-chrome "$@"
kill %1